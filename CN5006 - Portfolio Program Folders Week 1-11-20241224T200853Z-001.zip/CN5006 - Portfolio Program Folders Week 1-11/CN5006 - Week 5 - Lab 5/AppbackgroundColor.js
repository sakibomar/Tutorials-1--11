// AppbackgroundColor.js

// This functional component with propeties allows users to change the background color of the page 
// and displays a welcome message with their input name.

// Author: Saifullah Omar
// Date: 30/10/2024

// Importing the CSS file for styling the component
import './App.css';  

// Defining a functional component named AppColor that accepts props
function AppColor(props) {
    
    // Function to greet the user and change the background color based on input
    function greetUser(e) {
        // Change the document body's background color to the value from the button
        document.body.style.background = e.target.value;
        // Alerting a welcome message along with the value from the input field
        alert("Welcome Mr " + document.getElementById(props.color).value);
    }
    
    // Returning the JSX structure to be rendered
    return (
        // Setting a default background color and text color for the body
        <body style={{backgroundColor: 'powderblue', color: 'black'}}>
            <div className="App">  {/* Main container for the app */}
                <h1>{props.heading} </h1>  {/* Displaying the heading passed as a prop */}
                <p style={{color: 'blue', font: '30px Arial'}}> {/* Styling the paragraph */}
                    How to create function component.
                </p>
                <label className="label" id="lbl">{props.lbl}</label> {/* Displaying the label from props */}
                <input id={props.color} type="text" />  {/* Input field to take user input */}
                <button value={props.color} onClick={greetUser}> {/* Button to trigger greetUser function */}
                    Colour me {props.color} {/* Button text using the color prop */}
                </button>
            </div>
        </body>
    );
}

// Exporting the AppColor component for use in other files
export default AppColor;  

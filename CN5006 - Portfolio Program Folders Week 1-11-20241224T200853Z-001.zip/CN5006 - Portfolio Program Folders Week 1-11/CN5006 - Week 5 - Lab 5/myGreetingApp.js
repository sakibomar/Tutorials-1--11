import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './App.css';

function App() {
  const [teams, setTeams] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    // Fetch teams data when the component mounts
    axios
      .get('http://localhost:3000/topTeamsByWins/10') // API endpoint
      .then((response) => {
        setTeams(response.data.teams); // Set teams data in state
        setLoading(false);
      })
      .catch((err) => {
        setError('Error fetching data');
        setLoading(false);
      });
  }, []);

  if (loading) return <div>Loading...</div>;
  if (error) return <div>{error}</div>;

  return (
    <div className="container">
      <h1 className="title">Top 10 Football Teams</h1>
      <table className="teams-table">
        <thead>
          <tr>
            <th>#</th>
            <th>Team</th>
            <th>Country</th>
            <th>Wins</th>
            <th>Points</th>
          </tr>
        </thead>
        <tbody>
          {teams.map((team, index) => (
            <tr key={team._id}>
              <td>{index + 1}</td>
              <td>{team.Team}</td>
              <td>{team.Country}</td>
              <td>{team.Win}</td>
              <td>{team.Points}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default App;

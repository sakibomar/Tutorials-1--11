import React from 'react';
import ReactDOM from 'react-dom';
import App from './App';  // Importing the main App component
import './index.css';  // Global styles for the app

// Rendering the App component into the DOM
ReactDOM.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
  document.getElementById('root') // The element with id 'root' in your HTML file
);

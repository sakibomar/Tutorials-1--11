// Import React library to build the component structure
import React from 'react';
// Import ReactDOM to manage rendering of React components into the DOM
import ReactDOM from 'react-dom/client';
// Import the main CSS file to style the application
import './index.css';
// Importing the Calculator component and ReactDOM library to render the component on the webpage
import Calculator from './SimpleCalculator'; // Imports the Calculator component created in SimpleCalculator.js

// Access the root element in the HTML file to attach the React app
const root = ReactDOM.createRoot(document.getElementById('root'));

// Render the Calculator component inside the root element
// StrictMode helps catch potential problems in development mode, such as unsafe lifecycle methods or deprecated API usage
  // Renders the Calculator component on the page
root.render(
  <React.StrictMode>  
    <Calculator />    
  </React.StrictMode>
);

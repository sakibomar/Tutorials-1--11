// Importing the CSS file for styling and React library
import './App.css';
import React from 'react';

// Main Calculator component
// This component renders the calculator UI and handles calculations
function Calculator() 
{
  // calculate() function - Core logic of the calculator
  // Purpose: Retrieves input values, performs the operation, and displays the result.
  function calculate() 
  {
    // Get the values of both number inputs and operator selection
    // `parseFloat` converts the string input from the HTML element into a number with decimals
    const num1 = parseFloat(document.getElementById('num1').value); // First number input
    const num2 = parseFloat(document.getElementById('num2').value); // Second number input
    const operator = document.getElementById('operator').value;     // Selected operation (e.g., +, -, *, /)
    
    let result = 0; // Initialize result variable to store calculation outcome

    // Switch statement to determine the operation based on selected operator
    // This is the core logic where the selected operator decides which calculation to perform
    switch (operator) 
    {
      // Case for addition
      case '+':
        result = num1 + num2; // Adds num1 and num2
        break;

      // Case for subtraction
      case '-':
        result = num1 - num2; // Subtracts num2 from num1
        break;

      // Case for multiplication
      case '*':
        result = num1 * num2; // Multiplies num1 and num2
        break;

      // Case for division
      case '/':
        // Checks if num2 is not zero to prevent division by zero error
        result = num2 !== 0 ? num1 / num2 : 'Cannot divide by zero';
        break;

      // Default case for invalid operator
      default:
        // Message if operator is not one of +, -, *, or /
        result = 'Invalid Operation'; 
    }

    // Display the calculation result by updating the `result` paragraph's text content
    document.getElementById('result').innerText = `Result: ${result}`;
  }

  // Render the calculator's user interface
  // `return` defines the HTML structure of the calculator component
  return (
    <div 
      // Inline styles to give padding, border, width, and background color
      style={{ padding: '20px', border: '8px solid #ccc', width: '300px', background: '#54a1ff' }} 
       // Adds the 'App' class for additional styling from the CSS file
       // and underneath is the title of the calculator
      className="App">
      <h2>Simple Calculator</h2>  

      {/* First input for number 1 */}
      <input 
        // Type is 'number' to ensure only numerical input
        type="number"
        // ID to access this element in the calculate() function 
        id="num1" 
        // Placeholder text displayed when input is empty    
        placeholder="First Number" 
        // Inline styles for width and spacing
        style={{ width: '100%', marginBottom: '10px' }} />

      {/* Dropdown selector for choosing the operator */}
      <select 
        // ID to retrieve the selected operator in the calculate() function
        id="operator"  
        // Styles for dropdown
        style={{ width: '100%', marginBottom: '10px' }} >
        <option value="+">Add</option>        {/* Addition option */}
        <option value="-">Subtract</option>   {/* Subtraction option */}
        <option value="*">Multiply</option>   {/* Multiplication option */}
        <option value="/">Divide</option>     {/* Division option */}
      </select>

      {/* Second input for number 2 */}
      <input 
        // Type is 'number' to ensure only numerical input
        type="number" 
        // ID to access this element in the calculate() function
        id="num2"    
        // Placeholder text displayed when input is empty
        placeholder="Second Number" 
        // Inline styles for width and spacing
        style={{ width: '100%', marginBottom: '10px' }}/>

      {/* Button to trigger the calculation */}
      <button 
        onClick={calculate} // onClick event calls the calculate() function when button is clicked
        // Button styling
        style={{ width: '100%', padding: '10px', marginBottom: '10px' }} >
        Calculate
      </button>

      {/* Paragraph to display the result */}
      <p 
        // ID used to update this element with the calculation result
        id="result" 
        // Styling for result display
        style={{ fontWeight: 'bold', fontSize: '16px' }} >
        Result:
      </p>
    </div>
  );
}

// Export the Calculator component to make it available for import in other files
export default Calculator;

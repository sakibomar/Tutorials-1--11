/**
 * Person.js
 *
 * This module defines and exports the `Person` class, which is used to manage information 
 * about a person, including their name, location, and email.
 *
 * The class includes:
 * 
 * - A constructor that initializes the `name`, `location`, and `email` properties.
 * - `getPersonInfo`: A method that returns an object containing the person's details.
 * 
 * This module is imported and utilized in the main program to create and retrieve 
 * person information, allowing for organized handling of individual data.
 * 
 * @see index.js
 * 
 * @author Saifullah Omar
 * 
 * @version 16/10/2024
 */

// Define the 'Person' class
class Person 
{
    // Constructor to initialize personName, personLocation, and personEmail
    constructor(personName, personLocation, personEmail) 
    {
        this.name = personName;
        this.location = personLocation;
        this.email = personEmail;
    }

    // Method to return an object with person info
    getPersonInfo() 
    {
        return {
            Name: this.name,
            Location: this.location,
            Email: this.email
        };
    }
}
// Export the 'Person' class for use in other modules
module.exports = Person;

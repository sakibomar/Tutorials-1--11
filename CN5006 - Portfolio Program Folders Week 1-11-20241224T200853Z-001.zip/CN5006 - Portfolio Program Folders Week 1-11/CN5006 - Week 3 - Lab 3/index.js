/**
 * index.js
 *
 * This script serves as the main program, which demonstrates logging employee details and 
 * using imported modules to fetch student and person information. 
 *
 * The program performs the following tasks:
 * 
 * - Logs a welcome message with the employee's name and monthly salary.
 * - Defines and calls a function to log the employee's skills.
 * - Imports and uses two modules:
 *    - The `StudentInfo` module to log student details including name, location, 
 *      date of birth, and grade based on marks.
 *    - The `Person` module to create a new person instance and log the person's information.
 * 
 * This script combines employee-related details with additional student and person information 
 * to illustrate how modular code can be used for different data handling tasks.
 * 
 * @see StudentInfo.js
 * 
 * @see Person.js
 * 
 * @author Saifullah
 * 
 * @version 13/10/2024
 */

// Start of the program
console.log("\nProgram started");

// Declare variables for employee's name and salary
let employeeFullName = "David";
let monthlyWage = 9999;

// Define the function logEmployeeDetails to log employee name and salary
function logEmployeeDetails(empName, empSalary) 
{
    console.log(`\nWelcome, ${empName}. Your monthly salary is $${empSalary}`);
}

// Call the logEmployeeDetails function
logEmployeeDetails(employeeFullName, monthlyWage);

// Define a function to log employee skills
const logSkills = (skillSet) => 
{
    console.log(`\nExpert in ${skillSet}`);
};
logSkills("C++");

// Import the StudentInfo and Person modules
const studentInfoModule = require("./StudentInfo");
const personInfoModule = require("./Person");

// Log student information using the imported studentInfoModule
console.log(`\nStudent Name: ${studentInfoModule.getName()}`);
console.log(`\nLocation: ${studentInfoModule.getLocation()}`);
console.log(`\nDate of Birth: ${studentInfoModule.dob}`);
console.log(`\nDefault Grade: ${studentInfoModule.getStudentGrade()}`); // May return unexpected result without parameter
console.log(`\nGrade is: ${studentInfoModule.getStudentGrade(100)}`);  // Logs grade based on score

// Create and log a new person instance using the personInfoModule
const newPerson = new personInfoModule("Sam", "Canada", "Sam793@gmail.com");
console.log(`\nUsing Person Module:`, newPerson.getPersonInfo());

// End of the program
console.log("\nProgram ended");

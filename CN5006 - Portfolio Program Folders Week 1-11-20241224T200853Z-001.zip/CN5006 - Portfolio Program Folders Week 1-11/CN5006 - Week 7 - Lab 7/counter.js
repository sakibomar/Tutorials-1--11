// Import necessary dependencies from React and the CSS file for styling.
import React, { useState } from "react"; 
import "./App.css";

// Define the HookControlledButtonState component.
// This component demonstrates the use of React hooks to manage state in a functional component.
function HookControlledButtonState() {
  // Declare a state variable 'count' with an initial value of 0.
  // 'setCount' is the function used to update the value of 'count'.
  const [count, setCount] = useState(0);

  // Define the ClickHandle function, which increments the count state by 1 each time it is called.
  const ClickHandle = () => {
    // Update the count state to the current value plus 1.
    setCount(count + 1); 
  };

  // Render the component's UI.
  // Includes a heading displaying the current count and a button to trigger the ClickHandle function.
  return (
    <div className="App-header">
      {/* A form to group the heading and button elements visually */}
      <form>
        {/* Display the current count inside the heading */}
        <h1>Click Counts are {count}</h1>

        {/* Button element that triggers the ClickHandle function when clicked.
            It also displays the current count next to the button label. */}
        <button type="button" onClick={ClickHandle}>
          Click me {count}
        </button>
      </form>
    </div>
  );
}
// Export the HookControlledButtonState component for use in other parts of the application.
export default HookControlledButtonState;
